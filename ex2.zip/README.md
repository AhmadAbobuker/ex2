Full instructions: https://docs.google.com/document/d/1kWThYLIKOXCXjynnayRY3Z-A2-3fybM6cj8oybgBWmM/edit?usp=sharing
